<?php
include_once '../Lib/helpers.php';
if(isset($_GET['module'])){
    resolve();
}
<section class="about_section layout_padding">
    <div class="container  ">

      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/about-img.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                Nosotros Somos El Extranjero
              </h2>
            </div>
            <p>
              Quisimos presentar en un espacio familiar, comida rapida de alta calidad con los mejores ingredientes, acompañados de un sabor caracteristico que nos posicionaron como uno de los mejores sitios de comida rapida de la ciudad, cada fin de semana los caleños nos prefieren para acompañar sus cenas. El espacio acogedor o la musica en vivo que tenemos los días sabados son algunas de las razones por las cuales nuestros clientes nos prefieren. Si viejes al Extranjero, entenderás por qué todos vienen aqui. Te esperamos.
            </p>
            <a href="">
              Leer más
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
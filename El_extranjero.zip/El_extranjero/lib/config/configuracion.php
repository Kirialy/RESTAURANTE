<?php		    
    
    $servidor="127.0.0.1";
    $usuario="root";
    $clave="1234567890mati";
    $puerto=3306;
    $baseDatos="restaurante";  

?>